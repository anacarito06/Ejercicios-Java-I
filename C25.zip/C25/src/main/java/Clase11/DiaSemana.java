package clase11;

public enum DiaSemana {
    LUNES,MARTES,MIERCOLES
}
