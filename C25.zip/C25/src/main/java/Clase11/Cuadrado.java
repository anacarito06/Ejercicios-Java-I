package Clase11;

public class Cuadrado implements clase11.FiguraGeometrica {

    int lado;

    Cuadrado(){
        this.lado=3;
    }

    @Override
    public int calcularArea() {
        return lado*lado;
    }
}
