package clase11;

public interface FiguraGeometrica {
    public int calcularArea();
}