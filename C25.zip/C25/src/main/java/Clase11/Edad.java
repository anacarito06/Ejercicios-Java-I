import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Edad {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Por favor, ingrese su año de nacimiento (YYYY): ");
        int year = scanner.nextInt();

        System.out.print("Por favor, ingrese su mes de nacimiento (MM): ");
        int month = scanner.nextInt();

        System.out.print("Por favor, ingrese su día de nacimiento (DD): ");
        int day = scanner.nextInt();

        LocalDate fechaNacimiento = LocalDate.of(year, month, day);
        LocalDate fechaActual = LocalDate.now();

        int edad = calcularEdad(fechaNacimiento, fechaActual);

        System.out.println("Tienes " + edad + " años.");

        scanner.close();
    }

    public static int calcularEdad(LocalDate fechaNacimiento, LocalDate fechaActual) {
        if ((fechaNacimiento != null) && (fechaActual != null)) {
            return Period.between(fechaNacimiento, fechaActual).getYears();
        } else {
            return 0;
        }
    }
}



