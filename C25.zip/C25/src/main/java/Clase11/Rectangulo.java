package Clase11;

public class Rectangulo implements clase11.FiguraGeometrica {

    int largo;
    int ancho;

    Rectangulo(){
        this.ancho=10;
        this.largo=2;
    }

    @Override
    public int calcularArea() {
        return largo*ancho;
    }
}