


//PODEMOS ESCRIBIR

//TODO falta terminar

/*
Multi Linea
*/

import java.util.Scanner;

public class MiPrimeraClase {


    public static void main(String[] args) {
        //primitivos
        long numeroLargos;
        int numero1;
        double fraccion1;
        boolean esUnNumero;
        char letra='A';


        //wrapper
        Integer numero2;
        Double fraccion2;
        Boolean bolean;
        Character caracter2;
        Long numerosLargos2;
        //Objetos
        String palabra="Hola mundo";

        int a;
        int b =25;
        Scanner scanner = new Scanner(System.in);
        Scanner scanner1;
        scanner1= new Scanner(System.in);
        System.out.println("Hola mundo.");




    }
}