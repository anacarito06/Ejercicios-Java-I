import Actividades.Celular;

public class Clase4 {

    public static void main(String[] args) {

        Persona persona = new Persona("Mauricio",'h');

        System.out.println("el genero de "+persona.getNombreCompleto()+" es: "+persona.getGenero());

    }
}