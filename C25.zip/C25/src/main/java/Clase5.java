public class Clase5 {
    public static void main(String[] args) {

        int edad =30;

        if (edad>17){
            System.out.println("Es mayor de edad");
        }else {
            System.out.println("Es menor de edad");
        }
        int diaSemana=4;

        switch(diaSemana){
            case 1:
                System.out.println("Lunes");
                break;
            case 2:
                System.out.println("Martes");
                break;
            case 3:
                System.out.println("Miercoles");
                break;
            default:
                System.out.println("Dia no valido");
        }
    }
}
